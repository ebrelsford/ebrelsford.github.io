DCNR_StateParks201308
=====================

PA state parks.

via http://www.pasda.psu.edu/default.asp


dcnr_007772
===========

The Marcellus shale within PA.

via http://www.pasda.psu.edu/default.asp


FDNY_Firehouse_Listing.csv
==========================

via https://data.cityofnewyork.us/Public-Safety/FDNY-Firehouse-Listing/hc8x-tcnd


Oil_Gas_Well_Historical_Production_Report.csv
=============================================

via: https://www.paoilandgasreporting.state.pa.us/publicreports/Modules/DataExports/DataExports.aspx


PaCounty2015_01
===============

PA counties.

via http://www.pasda.psu.edu/default.asp
