PROJECTION INFORMATION

The data is in the Geographic projection and uses the WGS84 datum.
