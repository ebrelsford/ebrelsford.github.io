Data sources
============

AirBnB
------

Via Inside AirBnB (http://insideairbnb.com/), approximate locations of AirBnB
rentals accessed January 1 2015.


Coops
-----

Created by UHAB, sent via email.


Mitchell-Lama
-------------

Created by UHAB, sent via email.
